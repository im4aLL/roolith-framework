<!-- header -->
<!-- is-sticky -->
<header class="layout-header is-sticky">
    <!-- logo -->
    <div class="layout-header-primary">
        <a href="<?= route("admin.home") ?>" class="layout-header-logo">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 239.7 68">
                <path fill="var(--r-color-info)"
                    d="M81.6 42.5c0 4.2-.7 8.2-2.4 11.9-2.7 6-7.3 10.1-13.6 12.1-6.1 1.9-12.2 2-18.3.1-8.5-2.6-13.6-8.5-15.6-17.1-1.2-5.4-1.1-10.8.7-16.1 2.4-7.3 7.3-12.2 14.6-14.5 6.2-1.9 12.5-2 18.7.1 8.1 2.7 13 8.4 15 16.6.7 2.2.9 4.6.9 6.9zm-14.6.1c0-1.1 0-2.3-.2-3.4-.3-2.4-.8-4.8-2-7-2.1-4-6.2-5.8-10.6-4.9-3.5.7-5.8 3-7.1 6.2-1.3 3-1.6 6.1-1.6 9.3 0 3.3.4 6.5 1.8 9.5 2 4.3 5.9 6.4 10.5 5.7 3.5-.5 5.8-2.6 7.2-5.6 1.6-3.1 2-6.4 2-9.8z">
                </path>
                <path fill="var(--r-global-font-color)"
                    d="M165.8 42.5V28.7c0-.5-.1-.7-.6-.6h-3.7c-1.8 0-3-1.2-3-3v-3.9c0-1.2.9-2.1 2.1-2.1h4.4c.6 0 .7-.2.7-.8V9.1c0-1.2.9-2.1 2.1-2.1H178c1.2 0 1.9.7 1.9 1.9v9.5c0 .6.2.7.7.7h7c.4 0 .7.1 1.1.2 1.1.4 1.4.8 1.4 2v4.6c0 1.3-.9 2.2-2.1 2.2h-7.4c-.5 0-.6.1-.6.6v22.9c0 .9.1 1.7.2 2.6.5 2.6 1.7 3.7 4.4 3.9.7.1 1.5.1 2.2.1.5 0 .9.1 1.3.3.7.4 1.1.9 1.1 1.8-.1 1.5 0 2.9 0 4.4 0 .5-.1 1-.3 1.5-.4.7-.9 1.1-1.7 1.2-3.5.4-7 .6-10.5.2-1.4-.1-2.9-.4-4.2-.9-3.8-1.3-5.7-4-6.3-7.9-.4-2.8-.3-5.6-.4-8.4v-7.9z">
                </path>
                <path fill="var(--r-global-font-color)"
                    d="M76.1 62.2c3.1-3 5.2-6.6 6.5-10.7.7 1.2 1.4 2.2 2.3 3 3.5 3.2 10.7 3.4 14.2-1.8 1.5-2.3 2.3-4.9 2.6-7.6.4-3.7.4-7.4-.6-11-.7-2.4-1.7-4.5-3.6-6.2-3.5-3.2-11-3.3-14.4 2.3-.3.5-.6 1.1-1 1.7-.1-.3-.3-.7-.4-1-1.5-3.6-3.9-6.5-6.8-9.1-.5-.4-.4-.5 0-.9 3.3-2.6 7.2-4 11.3-4.6 5-.7 9.9-.5 14.7 1.1 8.2 2.8 13.1 8.7 14.9 17.1 1.2 5.6 1 11.3-1 16.7-2.9 7.9-8.7 12.7-16.9 14.4-6.3 1.3-12.5.9-18.4-1.6-1.2-.4-2.3-1-3.4-1.8z">
                </path>
                <path fill="var(--r-global-font-color)"
                    d="M119.2 30.4V2.7c0-1.3.9-2.2 2.2-2.2h9.7c1.3 0 2.2.9 2.2 2.2v49.4c0 .9 0 1.7.1 2.6.1 1.5.8 2.3 2.3 2.5.5.1 1 .1 1.5.2 1.2 0 1.7.6 1.7 1.7 0 1.9.1 3.9-.1 5.8 0 .3-.1.5-.2.8-.4 1.2-.7 1.4-1.9 1.5-2.8.2-5.6.4-8.3.2-1.2-.1-2.4-.3-3.6-.7-3.3-1.2-5-3.7-5.4-7.1-.3-2.5-.3-5-.3-7.5.1-7.3.1-14.5.1-21.7z">
                </path>
                <path fill="var(--r-global-font-color)"
                    d="M14.6 27.6c1-1.8 2-3.6 2.9-5.4.4-.8 1-1.5 1.7-2 2.5-1.9 5.3-2.8 8.5-2.7.9 0 1.7.3 2.2 1.1.3.4.4.7.4 1.2v8.9c0 .5-.1.6-.6.6-1.9-.1-3.9-.1-5.8.3-4.4.9-7.1 3.6-8.4 7.8-1 3.2-1.1 6.4-1.1 9.7v17.3c0 1.4-.9 2.4-2.3 2.4H3.7c-.5 0-1.1 0-1.6-.1-1.2-.2-1.8-.9-1.8-2V21.2c0-1.6.7-2.3 2.3-2.3h9.7c1.1 0 2.1 1 2.1 2.1v6.8l.2-.2z">
                </path>
                <path fill="var(--r-global-font-color)"
                    d="M156.1 42.5v22.2c0 1.3-.7 2-2 2H144c-1.2 0-2-.8-2-2V20.9c0-.4 0-.9.2-1.3.4-.6.8-.9 1.5-.9 3.4.1 6.8 0 10.2 0 .3 0 .5 0 .8.1 1.1.4 1.3.6 1.3 1.7.1 7.3.1 14.6.1 22z">
                </path>
                <path fill="var(--r-global-font-color)"
                    d="M149.2 14.5c-1.2 0-2.2-.1-3.1-.5-2.6-.9-4.1-2.8-4.4-5.5-.2-1.3-.1-2.5.3-3.7 1-2.9 3.2-4.2 6.1-4.5 2.1-.2 4.1.1 5.9 1.4 2.5 1.9 3.1 4.6 2.4 7.5-.6 2.8-2.5 4.4-5.3 5.1-.8.1-1.5.2-1.9.2z">
                </path>
                <path fill="var(--r-global-font-color)"
                    d="M239.8 39.9c0-3.5 0-6.9-.6-10.3-1-5.3-4-9.1-9.1-10.9-3.3-1.2-6.6-1.4-10.1-1.1-.6 0-1.2.1-1.8.2h.1c-9.1 1-10.9 8.5-10.9 8.5v-1c0-7.7-.1-15.4-.1-23.1 0-.6-.2-1-.7-1.3-.6-.5-1.2-.7-2-.7h-9.2c-1.5 0-2.4.9-2.4 2.4V65.3c.1.7.8 1.5 1.4 1.5 3.7 0 7.3.2 11-.1 1.3-.1 1.7-.6 1.7-1.9V43.6c0-3.3.4-6.5 1.5-9.6 1.6-4.3 4.7-7.2 9.8-6.5 3.3.4 5.6 2.3 6.5 5.5.6 2 .5 4.1.5 6.2V65c0 .9 1 1.9 1.8 1.9h10.1c1.3 0 2.2-1 2.2-2.3.3-8.4.3-16.6.3-24.7z">
                </path>
            </svg>
        </a>

        <button class="layout-header-sidebar-toggle" id="js-layout-header-sidebar-toggle">
            <i class="iconoir-transition-left-solid<?= getUiStateByKey("compact") == "compact" ? " is-hidden" : null ?>"
                data-show-when="expanded"></i>
            <i class="iconoir-transition-right-solid<?= getUiStateByKey("compact") == "compact"
                ? null
                : " is-hidden" ?>"
                data-show-when="collapsed"></i>
        </button>
    </div>
    <!-- logo -->

    <!-- header cta -->
    <div class="layout-header-secondary">
        <!-- search -->
        <form action="<?= route("admin.global.search") ?>" class="form layout-header-search">
            <div class="form-field form-field-search" id="global-search-input">
                <span class="form-field-search-icon"><i class="icon icon-search"></i></span>
                <input type="text" name="q" class="form-input" placeholder="Search ..." autocomplete="off" />
                <i class="form-field-search-loading-icon"></i>

                <div class="form-field-search-hint"></div>
            </div>
        </form>
        <!-- search -->

        <!-- nav -->
        <ul class="nav nav-icon-only layout-header-nav">
            <li class="nav-item">
                <a href="#" class="nav-link" id="js-toggle-mode">
                    <i class="iconoir-half-moon"></i>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?= route("admin.file.manager") ?>" class="nav-link">
                    <i class="iconoir-folder"></i>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?= route("admin.messages.index") ?>" class="nav-link">
                    <i class="iconoir-app-notification-solid"></i>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?= route("admin.siteSettings") ?>" class="nav-link">
                    <i class="iconoir-settings"></i>
                </a>
            </li>
            <?php if ($global["isAnalyticsEnabled"]): ?>
            <li class="nav-item">
                <a href="<?= route("admin.analytics.index") ?>" class="nav-link">
                    <i class="iconoir-graph-up"></i>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        <!-- nav -->

        <!-- avatar -->
        <div class="avatar layout-header-avatar">
            <figure class="avatar-fig rounded-circle">
                <img src="<?= getGravatarUrl() ?>" alt="" />
            </figure>
            <a href="#" class="avatar-label">
                <?= $global["user"]->name ?>
            </a>
            <div class="avatar-primary-block">
                <span>
                    <?= $global["user"]->role ?>
                </span>
                <a href="<?= route("admin.auth.logout") ?>">Sign out</a>
            </div>
        </div>
        <!-- avatar -->
    </div>
    <!-- header cta -->
</header>
<!-- header -->

<!-- left -->
<div class="layout-primary">
    <aside class="layout-sidebar">
        <?php $this->inject("admin/partials/admin-sidebar"); ?>
    </aside>
</div>
<!-- left -->
