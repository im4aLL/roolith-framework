<?php
namespace App\Models\Admin;

use App\Models\Model;

class AdminPageModule extends Model
{
    protected string $table = "module_page";
}
