<?php
namespace App\Models\Admin;

use App\Models\Model;

class AdminMessage extends Model
{
    protected string $table = 'messages';
}
