<?php
namespace App\Models\Admin;

use App\Models\Model;

class AdminPageCategory extends Model
{
    protected string $table = 'page_category';
}
