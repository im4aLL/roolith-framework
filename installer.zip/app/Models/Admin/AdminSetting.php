<?php
namespace App\Models\Admin;

use App\Models\Model;

class AdminSetting extends Model
{
    protected string $table = 'settings';
}
