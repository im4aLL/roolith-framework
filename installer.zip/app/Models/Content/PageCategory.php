<?php
namespace App\Models\Content;

use App\Models\Model;

class PageCategory extends Model
{
    protected string $table = 'page_category';
}
