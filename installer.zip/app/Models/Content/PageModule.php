<?php
namespace App\Models\Content;

use App\Models\Model;

class PageModule extends Model
{
    protected string $table = 'module_page';
}
