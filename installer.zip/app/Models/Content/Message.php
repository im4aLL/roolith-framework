<?php
namespace App\Models\Content;

use App\Models\Model;

class Message extends Model
{
    protected string $table = 'messages';
}
