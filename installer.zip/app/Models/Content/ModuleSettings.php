<?php
namespace App\Models\Content;

use App\Models\Model;

class ModuleSettings extends Model
{
    protected string $table = 'module_settings';
}
