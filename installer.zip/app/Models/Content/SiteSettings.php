<?php
namespace App\Models\Content;

use App\Models\Model;

class SiteSettings extends Model
{
    protected string $table = 'settings';
}
