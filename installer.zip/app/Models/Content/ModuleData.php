<?php
namespace App\Models\Content;

use App\Models\Model;

class ModuleData extends Model
{
    protected string $table = 'module_data';
}
