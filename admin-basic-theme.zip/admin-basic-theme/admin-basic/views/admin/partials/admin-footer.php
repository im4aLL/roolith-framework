    <script src="<?= $this->url('assets/js/admin.js' . '?v=' . getVersion()) ?>"></script>

</body>
</html>
